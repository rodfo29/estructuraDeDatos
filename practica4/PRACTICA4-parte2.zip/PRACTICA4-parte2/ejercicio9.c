#include <stdio.h>
#include <stdlib.h>



// 9. Implemente la función char *trimAll(char *str) en C, que dado un string
// elimine los blancos al principio, al final y solo deje un blanco entre palabras.


int len(char*cadena){
    int i=0;
    while(cadena[i]!='\0'){
        i++;
    }
    return i;
}
//   martin   
char *trimAll(char *str){

    int longitud_cad=len(str);
    // declaramos punteros al inicio y al final de la cadena.
    char*ptr_inicio=str;
    char*ptr_final=str+(longitud_cad-1);

    //Quitamos espacios el inicio de la cadena.
    while (*ptr_inicio==' ')
    {
        ptr_inicio++;
    }
    
    // Quitamos los espacios al final de la cadena.
    while(*ptr_final==' '){
        if (*(ptr_final-1)!=' '){
            *ptr_final='\0';
        }else{
            ptr_final--;
        }

    }

    // determinamos la longitud de la cadena sin espacios al inicio y al final.
    int long_cad_no_space=len(ptr_inicio);
    // reservamos memoria de la nueva cadena.
    char*nueva_cad=(char*)malloc((long_cad_no_space+1)*sizeof(char));
    // Como el puntero (nueva_cad) lo usaré para desplazarme en la nueva cadena, ptr_nueva_cad será el puntero que retornaré.
    char*ptr_nueva_cad=nueva_cad;
    while(*ptr_inicio!='\0'){
        
        if (*ptr_inicio!=' '){
            *nueva_cad=*ptr_inicio;
            ptr_inicio++;
            nueva_cad++;
        }
        else{
            
            while (*ptr_inicio==' ')
            {
                
                ptr_inicio++;
            }
            ptr_inicio--;
            *nueva_cad=*ptr_inicio;
            ptr_inicio++;
            nueva_cad++;
        }

    }
    *nueva_cad=*ptr_inicio;
    return ptr_nueva_cad;
    
}




int main(){
    char nombre[]="   martin   pinto";
    char*nueva_cadena=trimAll(nombre);

    printf("La cadena sin espacios es :%s\n",nombre);
    printf("La cadena sin espacios es:%s\n",nueva_cadena);
    free(nueva_cadena);
}