#include <stdio.h>
#include <stdlib.h>



/*¿Qué problema tiene la siguiente función? Reescriba el código de la
función para arreglarlo, sin cambiar las premisas de uso.


char* WordInput(){
char word[20];
printf ("Type a word: ");
scanf ("%s", word);
return word;
}

*/


/*
EXPLICACIÓN: 
La función está retornando un puntero al primer caracter de una cadena la cual desaparece luego que termina la ejecuciòn de la función.

SOLUCIÓN:
Mediante el uso de malloc, podemos reservar de forma dinámica un bloque de memoria el cual permanecerá existente luego de la ejecución de la función. */
char* WordInput(){

char*word=(char*)malloc(20*sizeof(char));
printf ("Type a word: ");
scanf ("%s", word);
return word;
}

int main(){

char*cadena=WordInput();
printf("La cadena es: %s\n",cadena);
// luego debemos liberar esa memoria que reservamos con malloc mediante el uso de la función free().
free(cadena);



}