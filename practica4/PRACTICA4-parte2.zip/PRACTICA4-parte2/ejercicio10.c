#include <stdio.h>
#include <stdlib.h>

// validar que la diagonal principal de una matriz sea igual a 0 los elementos.
int diagonal_principal(int **matriz,int tamano){
    int acumulador=0; // si la suma de los elementos de la diagonal principal es 0 entonces todos los elementos son 0.
    for (int i=0;i<tamano;i++){
        for (int j=0;j<tamano;j++){
            if (i==j){
                acumulador+=matriz[i][j];

            }
        }
    }
    if (acumulador==0){
        return 1;
    }else{
        return 0;
    }
}


int main(){

    int tamano;
    printf("Ingresar tamano: ");
    scanf("%d",&tamano);
    int **matriz=(int**)malloc(tamano*sizeof(int));
    for (int i=0;i<tamano;i++){
        matriz[i]=(int*)malloc(tamano*sizeof(int));

    }

    printf("Ingresar valores a la matriz: \n");
    for (int i=0;i<tamano;i++){
        for (int j=0;j<tamano;j++){
            printf("Ingresar numero (%d)(%d)",i+1,j+1);
            scanf("%d",&matriz[i][j]);

        }
    }
    int diagonal=diagonal_principal(matriz,tamano);
    printf("es valor es: %d\n",diagonal);
    // liberamos los arreglos
    for (int i=0;i<tamano;i++){
        free(matriz[i]);
    }
    free(matriz);
}