#include <stdio.h>

/*8. Dado un string con una secuencia de paréntesis (que abren y cierran en
cualquier orden), escriba en C una función que verifiquen que están
balanceados.*/

// validamos que el string tenga paréntesis de forma par.
int existencia_parentesis(char*cadena){
    int i=0;
    int cont_parentesis=0;
    while (cadena[i]!='\0')
    {
        if (cadena[i]=='(' || cadena[i]==')'){
            cont_parentesis+=1;
        }
        i++;
    }
    
    if ((cont_parentesis%2==0)&&cont_parentesis>0){
        return 1;
    }else{
        return -1;
    }
    
}


// Validar que los paréntesis se encuentren balanceados.
int parentesis_balanceados(char*cadena){
    int existencia=existencia_parentesis(cadena);
    if (existencia==-1){
        
        return -1 ;
    }
    // contadores de paréntesis abiertos y cerrados.
    int ContParAbiertos=0;
    int ContParCerrados=0;
    int ContParPendientes=0; // Paréntesis los cuales no se les ha encontrado una pareja.
    // Contador de las parejas de parentesis
    int ContParejas=0;

    int i=0;
    while (cadena[i]!='\0')
    {

        if (cadena[i]=='('){
            ContParAbiertos+=1;
            if (cadena[i-1]=='('){
                ContParPendientes+=1;
            }

            if (cadena[i+1]==')'){
                ContParCerrados+=1;
                ContParejas+=1;
                i+=2;
            }
            else{
                i++;
            }
        }

        if (cadena[i]==')'&&i==0){
            return -1;
        }
        if(cadena[i]==')' && ContParPendientes>0){
            ContParCerrados+=1;
            ContParPendientes-=1;
            ContParejas+=1;
            i++;
        }
    }
    if (ContParejas==0){
        return-1;
    }
    if (((ContParAbiertos+ContParCerrados)/ContParejas)%2==0){
        return 1;
    }
    else{
        return -1;
    }
    
    }



int main(){
    char cadena[]="(((())";
    int validacion=parentesis_balanceados(cadena);
    printf("%d\n",validacion);


}

    