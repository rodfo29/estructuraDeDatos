#include <stdio.h>

// imprimir **mp
void imprimir_mp(int **mp, int filas, int columnas) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            printf("%d ", mp[i][j]);
        }
        printf("\n");
    }
}

// imprimir ma
void imprimir_ma(int ma[][5], int filas, int columnas) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            printf("%d ", ma[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int f0[] = {0, 1, 2, 3, 4},
        f1[] = {10, 11, 12, 13, 14},
        f2[] = {20, 21, 22, 23, 24},
        f3[] = {30, 31, 32, 33, 34},
        f4[] = {40, 41, 42, 43, 44},
        *fp[] = {f0, f1, f2, f3, f4},
        **mp=fp;

    imprimir_mp(mp, 5, 5);  

    int ma[][5] = {
        {0, 1, 2, 3, 4},
        {10, 11, 12, 13, 14},
        {20, 21, 22, 23, 24},
        {30, 31, 32, 33, 34},
        {40, 41, 42, 43, 44}
    };
    imprimir_ma(ma, 5, 5); 
    return 0;
}
