#include <stdio.h>
#include <stdlib.h>


void imprimir_hojas_arbol(Nodo* raiz) {
    if (raiz == NULL) {
        return;
    }

    if (raiz->izquierdo == NULL && raiz->derecho == NULL) {
        printf("%d ", raiz->valor);
    }

    // Recorremos los subárboles izquierdo y derecho
    imprimirHojas(raiz->derecho);
    imprimirHojas(raiz->izquierdo);
}

void imprimirNivel(Nodo* raiz, int nivel) {
    if (raiz == NULL) {
        return ;
    }

    if (nivel == 0) {
        printf("%d ", raiz->valor);
    }
    else {
        // Disminuimos el nivel y seguimos buscando
        imprimirNivel(raiz->izquierdo, nivel -1);
        imprimirNivel(raiz->derecho, nivel - 1);
    }
}

int Arbolesiguales(Nodo* raiz1, Nodo* raiz2) {
    if (raiz1 == NULL && raiz2 == NULL) {
        return 1;
    }

    if (raiz1 == NULL || raiz2 == NULL) {
        return 0;
    }

    // Comparamos los valores y verificamos 
    return (raiz1->valor == raiz2->valor) && Arbolesiguales(raiz1->izquierdo, raiz2->izquierdo) && Arbolesiguales(raiz1->derecho, raiz2->derecho);
}


// Esta función la voy a necesitar para poder verificar si los árboles tienen los mismos elementos
int existe(Nodo* raiz, int valor) {
    if (raiz == NULL) {
        return 0;
    }

    if (valor < raiz->valor) {
        return existe(raiz->izquierdo, valor);
    }
    else if (valor > raiz->valor) {
        return existe(raiz->derecho, valor); 
    }
    else {
        return 1; 
    }
}

int Arboles_con_los_mismos_elementos(Nodo* raiz1, Nodo* raiz2) {
    if (raiz1 == NULL && raiz2 == NULL) {
        return 1;
    }

    if (raiz1 == NULL || raiz2 == NULL) {
        return 0;
    }

    // Verificamos si el valor está presente en ambos árboles
    return existe(raiz2, raiz1->valor) &&    Arboles_con_los_mismos_elementos(raiz1->izquierdo, raiz2) && Arboles_con_los_mismos_elementos(raiz1->derecho, raiz2);
}

int sucesor(Nodo* raiz, int valor, int* sucesorValor) {
    Nodo* actual = raiz;
    Nodo* sucesor = NULL;

    while (actual != NULL) {
        if (valor < actual->valor) {
            sucesor = actual;
            actual = actual->izquierdo;
        }
        else if (valor > actual->valor) {
            actual = actual->derecho;
        }
        else {
            // En caso de que la función encuentre el nodo vamos va buscar el sucesor
            if (actual->derecho != NULL) {
                Nodo* temp = actual->derecho;
                while (temp->izquierdo != NULL) {
                    temp = temp->izquierdo;
                }
                *sucesorValor = temp->valor;
                return 1;
            }
            break;
        }
    }

    return -1;
}



int main(){

}