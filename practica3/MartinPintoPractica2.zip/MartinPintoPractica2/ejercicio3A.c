
#include <stdio.h>

// 3. Una cadena de caracteres (string) es un vector de caracteres que termina
// con un carácter '\0', por lo que las funciones que manipulan strings esperan
// que los mismos terminen en ‘\0'.


// a. Dada la siguiente función

void strcat (char s[], char t[]) {
int i, j;
i = j = 0;
while (s[i] != '\0') {
i++;
}
while ((s[i++] = t[j++]) != '\0') {

}
}

// Reescríbala usando apuntadores. ¿Qué ventaja se tiene?


/* Ventaja: el código con punteros puede ser más directo y fácil de leer, ya que no necesita manejar múltiples variables de índice (i y j), además que 
la lógica de avanzar en la cadena es más intuitica con punteros (s++ y t++)*/

void ptr_str_cat(char*s,char*t){
    while(*s!='\0'){
        s++; // desplazamos el puntero al siguiente caracter. 

    }
    
    
    while (*t!='\0')
    {   

        *s=*t; // asignamos caracteres a la cadena s.
    printf("letra actual: %c\n",*t);
        t++;// desplazamos el puntero al siguiente caracter.
        s++;// desplazamos el puntero al siguiente caracter.

    }
        *s=*t; // asignamos el caracter nulo a la cadena s.

}
        
    











int main(){

    char cadena1[15]="martin";
    char cadena2[]="Pinto";
    

    ptr_str_cat(cadena1,cadena2);
    printf("La cadena luego de concatenr es: %s",cadena1);



}