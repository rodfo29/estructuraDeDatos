// 2. Dado el siguiente programa en C:

#include <stdio.h>

char string1[12] = {'H','o','l','a',' ','M','u','n','d','o','\0'}; // sizeof nos devuelve el tamaño en bytes del arreglo ( cada caracter= 1 byte) por lo tanto, la salida es igual a 12.
char string2[] = "Hola Mundo"; // nos devuelve en tamaño de la cadena de texto ya que el tamaño en bytes de 1 char es igual == 1, nos devolverá 11, ya que el caracter nulo también se cuenta.

char *string3 = "Hola Mundo"; // en este caso sizeof No devolverá el tamaño en bytes de la cadena a la que apunta, sino que devolverá el tamaño en bytes del puntero.
char *ap_string[] = {"Uno","Dos","Tres"}; // Ya que el arreglo contiene punteros, sizeof(ap_string) nos devolverá el valor de los punteros que se encuentren en el arreglo.
char abc[][6] = {"Uno","Dos","Tres"}; // ya que este arreglo le definimos que almacenará subarreglos de longitud 6, sizeof() nos devolverá la multiplicación de los números de subarreglos por 6.
int main(void){
printf("Tamaño de string1:%d\n",sizeof(string1));
printf("Tamaño de string2:%d\n",sizeof(string2));
printf("Tamaño de string3:%d\n",sizeof(string3));
printf("Tamaño de ap_string:%d\n",sizeof(ap_string));
printf("Tamaño de ABC:%d\n\n",sizeof(abc));
}

// Se desea que usted lo compile y explique la salida.



// EXPLICACIÓN: 

// char string1[12] = {'H','o','l','a',' ','M','u','n','d','o','\0'}; // sizeof nos devuelve el tamaño en bytes del arreglo ( cada caracter= 1 byte) por lo tanto, la salida es igual a 12.
// char string2[] = "Hola Mundo"; // nos devuelve en tamaño de la cadena de texto ya que el tamaño en bytes de 1 char es igual == 1, nos devolverá 11, ya que el caracter nulo también se cuenta.

// char *string3 = "Hola Mundo"; // en este caso sizeof No devolverá el tamaño en bytes de la cadena a la que apunta, sino que devolverá el tamaño en bytes del puntero.
// char *ap_string[] = {"Uno","Dos","Tres"}; // Ya que el arreglo contiene punteros, sizeof(ap_string) nos devolverá el valor de los punteros que se encuentren en el arreglo.
// char abc[][6] = {"Uno","Dos","Tres"}; // ya que este arreglo le definimos que almacenará subarreglos de longitud 6, sizeof() nos devolverá la multiplicación de los números de subarreglos que asignemos por 6.
