#include <stdio.h>

/*4. Dado un arreglo de enteros, se desea que usted:
a. Haga una función que calcule la ocurrencia de un número dado.
b. Siguiendo el prototipo: float relacionPI(int array[], int size), calcule la
división entre las suma de los valores pares y la suma de los valores
impares.*/

// a. Haga una función que calcule la ocurrencia de un número dado.
int NumeroOcurrencias(int*arreglo,int longitud,int NumeroBuscado){
    int apariciones=0;
    for (int i=0;i<longitud;i++){
        if (arreglo[i]==NumeroBuscado){
            apariciones++;
        }
    }
    return apariciones;
}

/*
b. Siguiendo el prototipo: float relacionPI(int array[], int size), calcule la
división entre las suma de los valores pares y la suma de los valores
impares.


*/

float relacionPI(int array[], int size){
    
    float suma_pares=0;
    float suma_impares=0;

    for (int i = 0; i < size; i++)
    {
        if (array[i]%2==0){
            suma_pares+=array[i];
        }else{
                suma_impares+=array[i];
            }
    }
    float div_pares_impares=suma_pares/suma_impares;
    return div_pares_impares;
}

    






int main(){

    int arreglo[]={1,2,3,3,12};
    int longitud=sizeof(arreglo)/sizeof(arreglo[0]);
    int NumeroBuscado;
    printf("Ingresar el número buscado: ");
    scanf(" %d",&NumeroBuscado);
    int ocurrencias=NumeroOcurrencias(arreglo,longitud,NumeroBuscado);
    printf("El numero total de ocurrencias del numero ingresado es: %d\n",ocurrencias);
    float div_pares_impares=relacionPI(arreglo,longitud);
    printf("La division de los numeros pares e impares del arreglo es: %.2f\n",div_pares_impares);


}


