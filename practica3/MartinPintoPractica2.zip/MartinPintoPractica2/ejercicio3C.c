#include <stdio.h>
/*Implemente, usando Lenguaje C, las siguientes funciones:


i. Que retorne el número de veces que el string s1 está en el
string s2.
int my_nsubstr(const char *s1, const char *s2)


ii. Invertir un string, por ejemplo, convierte a “abc” en “cba”,
trabaja sobre el mismo espacio apuntado por s.
void my_strrev(char *s)*/

// i) DETERMINAR EL NÚMERO DE VECES QUE EL STRING S1 ESTÁ EN EL STRING S2.

// determinamos la longitud de la cadena.
int longitud(const char* cadena){
    int i=0;
    while(cadena[i]!='\0'){
        i++;

    }
    return i;
}


// Determinar la cantidad de veces que aparece una subcadena.
int my_nsubstr(char*s1,char*s2){
 
 // calculamos las longitudes de ambas cadenas.
 int longitud_subcad=longitud(s1);
 int longitud_cad=longitud(s2);

 // definimos el contador de las apariciones.
    int Apariciones=0;
 // calculamos la cantidad de posiciones válidas.
 int posiciones_validas=longitud_cad-longitud_subcad;

  for (int i=0;i<=posiciones_validas;i++){
    char*ptr_s1=s1;
    char*ptr_s2=s2+i;
    while ((*ptr_s1==*ptr_s2)&&*ptr_s1!='\0')
    {
        ptr_s1++;
        ptr_s2++;


    }
    // si el puntero a la subcadena es igual al caracter nulo efectivamente estamos en presencia de una subcadena.
    if (*ptr_s1=='\0'){
        Apariciones++;

    }

  }
    return Apariciones;
}
    

// ii)  REVERTIR CADENA



// Revertir la cadena ingresada.
void my_strrev(char *s){
    int longitud_cadena=longitud(s)-1;

    int i=0,j=longitud_cadena;
    while (j>i)
    {
        char aux=s[i];
        s[i]=s[j];
        s[j]=aux;
        i++;
        j--;
    }
    

}

 







int main(){

    char nombre[]="martin pinto";
    char subcad[]="i";
    int apariciones=my_nsubstr(subcad,nombre);
    printf("La subcadena tiene un total de %d apariciones.\n",apariciones);
    my_strrev(nombre);
    printf("La cadena en reversa es: %s\n",nombre);

}