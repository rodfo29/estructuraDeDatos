#include <stdio.h>
#include <stdlib.h>

// b. Explique qué hacen las siguientes funciones:

int my_strlen(const char *s){
register const char *p = s;
while(*p) //*p!=‘\0'
p++;
return p-s;
}

void my_strcpy(char*d,const char*f){
    while (*d++=*f++)
    {
    }
    


}

char *my_strdump(const char *f){
char *d;
d=(char *)malloc(my_strlen(f)+1);
my_strcpy(d,f);
return d;
}



int my_substr(const char *s1, const char *s2){
int i,v;
const char *p1,*p2;
v=my_strlen(s2)-my_strlen(s1);
for(i=0;i<=v;i++)
for(p1=s1,p2=s2+i;*p1++==*p2++;)
if(*p1=='\0') return i;
return -1;
}

int main(){

char nombre[]="martin";
int result=my_strlen(nombre);
char*cadena=my_strdump(nombre);

printf("La salida es: %s",cadena);
free(cadena);



}


// EXPLICACIÓN: 
 
//  1) my_strlen: La función cuenta el número de caracteres en la cadena hasta encontrar el carácter nulo ('\0'), La expresión p - s calcula la diferencia entre los punteros y devuelve esa cuenta como la longitud de la cadena.
//  2) my_strcpy: Esta función lo que hace es que hace uso del operador de post-incremento para que poder acceder al valor de las variables a las cuales los punteros apuntan y luego desplazar a los punteros para poder reccorer todos los caracteres y hacer la asignación.
//  3) my_strdump: Copia los caracteres de una cadena en un bloque de memoria que reserva dinámicamente con malloc.
//  4) my_substr: Esta función se encarga de determinar si una subcadena se encuentra adentro de una cadena principal, en caso de éxito retorna el indice en donde empieza la subacdena, sino, devuelve -1.
