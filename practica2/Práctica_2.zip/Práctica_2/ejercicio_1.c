#include <stdio.h>

/*ALUMNO : MARTÍN PINTO

*/



int main(){

    printf("Hola mundo\n ");
    


}