#include <stdio.h>


int main(){
    int numero,cont_dig;
    printf("Ingresar numero: ");
    scanf("%d",&numero);

    while (numero>0)
    {
        cont_dig+=1;
        numero/=10;
        
    }
    printf("El numero tiene un total de %d digitos\n",cont_dig);
    




}