#include <stdio.h>

/*ALUMNO : MARTÍN PINTO

*/



int main(){
    int arreglo[3];

    // Llenamos el arreglo con los 3 números ingresados por el usuario.
    for (int i=0;i<3;i++){
        printf("\nIngresar numero %d: ",i+1);
        scanf("%d",&arreglo[i]);
    }
    int mayor=arreglo[0],menor=arreglo[0];
    
    float promedio=0;
    
    
    
    for (int i=0;i<3;i++){
        promedio+=arreglo[i];
        if (arreglo[i]>mayor){
            mayor=arreglo[i];
        }
        if (arreglo[i]<menor){
            menor=arreglo[i];


        }
    }
    printf("Los elementos del arreglo son:");

    for (int i=0;i<3;i++){
        printf(" %d",arreglo[i]);

    }

    printf("\n El numero mayor es : %d\n El numero menor es: %d\nEl promedio de los numeros ingresados es: %.2f\n ",mayor,menor,promedio/3);






}